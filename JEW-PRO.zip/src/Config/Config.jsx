export const CREATE_jwel = `${process.env.REACT_APP_jewl_SERVICE_URL}`;
